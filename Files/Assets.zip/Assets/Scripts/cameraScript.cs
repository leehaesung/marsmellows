﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cameraScript : MonoBehaviour {

	public float speedH = 2.0f;
	public float speedV = 2.0f;
//	public float speedTranslation = 1.0f;
	public float force = 1.0f;

	private float yaw = 0.0f;
	private float pitch = 0.0f;
	private Rigidbody rb;

	// Use this for initialization
	void Start () {
		rb = GetComponent<Rigidbody> ();
	}
	
	// Update is called once per frame
	void FixedUpdate () {

		yaw += speedH * Input.GetAxis ("Mouse X");
		pitch -= speedV * Input.GetAxis ("Mouse Y");

		transform.eulerAngles = new Vector3 (pitch, yaw, 0.0f);

		pitch = Mathf.Clamp(pitch, -90f, 90f);

		if (Input.GetKey (KeyCode.UpArrow)) {
//			transform.localPosition += transform.forward * speedTranslation * Time.deltaTime;
			rb.AddForce(transform.forward*force);
		} else if (Input.GetKey (KeyCode.DownArrow)) {
//			transform.localPosition -= transform.forward * speedTranslation * Time.deltaTime;
//			print ("Down");
			rb.AddForce(transform.forward*-force);
		} else if (Input.GetKey (KeyCode.LeftArrow)) {
//			transform.localPosition -= transform.right * speedTranslation * Time.deltaTime;
			rb.AddForce(transform.right*-force);
		} else if (Input.GetKey (KeyCode.RightArrow)) {
//			transform.localPosition += transform.right * speedTranslation * Time.deltaTime;
			rb.AddForce(transform.right*force);
		} else if (Input.GetKey (KeyCode.RightShift)) {
//			transform.localPosition += transform.up * speedTranslation * Time.deltaTime;
			rb.AddForce(transform.up*force);
		} else if (Input.GetKey (KeyCode.RightControl)) {
//			transform.localPosition -= transform.up * speedTranslation * Time.deltaTime;
			rb.AddForce(transform.up*-force);
		}

	}

//	private void moveForward(float speed) {
//		transform.localPosition += transform.forward * speedTranslation * Time.deltaTime;
//	}
//
//	private void moveBack(float speed) {
//		transform.localPosition -= transform.forward * speedTranslation * Time.deltaTime;
//	}
//
//	private void moveLeft(float speed) {
//		transform.localPosition -= transform.right * speedTranslation * Time.deltaTime;
//	}
//
//	private void moveRight(float speed) {
//		transform.localPosition += transform.right * speedTranslation * Time.deltaTime;
//	}
//
//	private void moveUp(float speed) {
//		transform.localPosition += transform.up * speedTranslation * Time.deltaTime;
//	}
//
//	private void moveDown(float speed) {
//		transform.localPosition -= transform.up * speedTranslation * Time.deltaTime;
//	}
}
